% fonction classification_foret (pour l'exercice 2)

function Y_pred = classification_foret(foret, X)

    

end