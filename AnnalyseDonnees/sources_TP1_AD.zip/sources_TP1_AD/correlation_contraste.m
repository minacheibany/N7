% function correlation_contraste (pour exercice_1.m)

function [correlation,contraste] = correlation_contraste(X)


    
end
