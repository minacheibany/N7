% fonction maximisation_classification_MAP (pour l'exercice 3)

function [pourcentage_meilleur_classification_MAP, p1_max, ...
          vecteur_pourcentages_bonnes_classifications_MAP] = ...
         maximisation_classification_MAP(X,Y,valeurs_p1,mu_1,Sigma_1,mu_2,Sigma_2)


    
end
