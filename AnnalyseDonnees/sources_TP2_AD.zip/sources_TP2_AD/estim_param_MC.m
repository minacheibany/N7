% fonction estim_param_MC (pour exercice_1.m)

function parametres = estim_param_MC(d,x,y)


    
end
