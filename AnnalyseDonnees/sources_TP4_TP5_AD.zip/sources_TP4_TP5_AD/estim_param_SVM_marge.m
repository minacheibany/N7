% fonction estim_param_SVM_marge (pour l'exercice 2)

function [X_VS,w,c,code_retour] = estim_param_SVM_marge(X,Y,lambda)



end