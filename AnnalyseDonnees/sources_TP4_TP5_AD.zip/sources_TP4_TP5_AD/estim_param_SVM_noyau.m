% fonction estim_param_SVM_noyau (pour l'exercice 3)

function [X_VS,Y_VS,Alpha_VS,c,code_retour] = estim_param_SVM_noyau(X,Y,sigma)



end
