% fonction classification_SVM_avec_noyau (pour l'exercice 3)

function Y_pred = classification_SVM_avec_noyau(X,sigma,X_VS,Y_VS,Alpha_VS,c)



end