% fonction maximisation_classification_SVM_noyau (pour l'exercice 5)

function [pourcentage_meilleur_classification_SVM_test, sigma_opt_test, ...
          vecteur_pourcentages_bonnes_classifications_SVM_app, ...
          vecteur_pourcentages_bonnes_classifications_SVM_test] = ...
          maximisation_classification_SVM_noyau(X_app,Y_app,X_test,Y_test,vecteur_sigma)



end