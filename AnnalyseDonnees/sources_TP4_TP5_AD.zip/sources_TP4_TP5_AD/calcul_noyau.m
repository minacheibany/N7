% fonction calcul_noyau (pour l'exercice 3)

function K = calcul_noyau(Xj,Xi,sigma)



end