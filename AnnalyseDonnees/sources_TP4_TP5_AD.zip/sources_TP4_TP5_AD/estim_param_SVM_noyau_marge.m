% fonction estim_param_SVM_noyau_marge (pour l'exercice 4)

function [X_VS,Y_VS,Alpha_VS,c,code_retour] = estim_param_SVM_noyau_marge(X,Y,sigma,lambda)



end
