% Fonction matrice_inertie (exercice_2.m)

function [M_inertie,C] = matrice_inertie(E,G_norme_E) 

    % A COMPLETER 

end