% Fonction calcul_proba (exercice_2.m)

function [x_min,x_max,probabilite] = calcul_proba(E_nouveau_repere,p)

    % A COMPLETER
    
end