% Fonction occultation_donnees (donnees_occultees.m)

function [x_donnees_bruitees_visibles, y_donnees_bruitees_visibles] = ...
         occultation_donnees(x_donnees_bruitees, y_donnees_bruitees, ...
                             theta_donnees_bruitees, thetas)
    
    % A COMPLETER

end