% Fonction calcul_G_et_R_moyen (exercice_1.m)

function [G, R_moyen, distances] = ...
                        calcul_G_et_R_moyen(x_donnees_bruitees,y_donnees_bruitees)

    % A COMPLETER

end