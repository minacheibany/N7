% Fonction tirages_aleatoires (exercice_2.m)

function [tirages_C,tirages_R] = tirages_aleatoires_uniformes(n_tirages,G,R_moyen)
    
    % A COMPLETER

end