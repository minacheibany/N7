% Fonction estim_param_Dorth_MC (exercice_4.m)

function [theta_Dorth,rho_Dorth] = ...
                 estim_param_Dorth_MC(x_donnees_bruitees,y_donnees_bruitees)



end