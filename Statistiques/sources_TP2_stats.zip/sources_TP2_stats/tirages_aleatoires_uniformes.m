% Fonction tirages_aleatoires_uniformes (exercice_1.m)

function [tirages_angles,tirages_G] = tirages_aleatoires_uniformes(n_tirages,taille)

    % Tirages aleatoires d'angles : moyenne = 0 / demi-repartition = pi/2
    tirages_angles = 0;
    % Tirages aleatoires de points pour se trouver sur la droite (sur [-20,20])
    tirages_G = 0;

end